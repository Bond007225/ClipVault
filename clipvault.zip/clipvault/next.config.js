/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['cdn.cloudflare.steamstatic.com', 'static-cdn.jtvnw.net', 'avatars.githubusercontent.com'],
  },
}

module.exports = nextConfig
