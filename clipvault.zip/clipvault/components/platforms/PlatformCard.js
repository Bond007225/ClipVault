import { useState } from 'react';
import { Check, RefreshCw, Unlink } from 'lucide-react';

export default function PlatformCard({ platform }) {
  const [connected, setConnected] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [username, setUsername] = useState('');
  const [inputVal, setInputVal] = useState('');
  const [showInput, setShowInput] = useState(false);

  const handleConnect = () => {
    if (!showInput) { setShowInput(true); return; }
    if (!inputVal.trim()) return;
    setUsername(inputVal.trim());
    setConnected(true);
    setShowInput(false);
  };

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 1800);
  };

  const handleDisconnect = () => {
    setConnected(false);
    setUsername('');
    setInputVal('');
  };

  return (
    <div style={{
      background: 'var(--bg-surface)',
      border: `1px solid ${connected ? platform.color + '40' : 'var(--border-subtle)'}`,
      borderRadius: 'var(--radius-lg)',
      padding: '18px 20px',
      transition: 'all 0.2s',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Color accent bar */}
      {connected && (
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 2, background: platform.color }} />
      )}

      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
        {/* Icon */}
        <div style={{
          width: 44, height: 44, borderRadius: 'var(--radius-md)',
          background: platform.color + '18',
          border: `1px solid ${platform.color}30`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 20, flexShrink: 0,
        }}>{platform.emoji}</div>

        {/* Info */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600 }}>{platform.name}</span>
            {connected && <span className="badge badge-green">Connected</span>}
          </div>
          <p style={{ fontSize: 12, color: 'var(--text-tertiary)', marginBottom: 10, lineHeight: 1.5 }}>
            {connected ? `@${username} · ${platform.tagline}` : platform.description}
          </p>

          {/* Input for username */}
          {showInput && !connected && (
            <input
              value={inputVal}
              onChange={e => setInputVal(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleConnect()}
              placeholder={`Enter your ${platform.name} username`}
              style={{ marginBottom: 10, fontSize: 13 }}
              autoFocus
            />
          )}

          {/* Actions */}
          <div style={{ display: 'flex', gap: 8 }}>
            {!connected ? (
              <button
                onClick={handleConnect}
                className="btn btn-sm"
                style={{ background: platform.color + '18', color: platform.color, border: `1px solid ${platform.color}40` }}
              >
                {showInput ? 'Confirm' : 'Connect'}
              </button>
            ) : (
              <>
                <button
                  onClick={handleSync}
                  className="btn btn-ghost btn-sm"
                  style={{ gap: 5, display: 'flex', alignItems: 'center' }}
                  disabled={syncing}
                >
                  <RefreshCw size={12} style={{ animation: syncing ? 'spin 1s linear infinite' : 'none' }} />
                  {syncing ? 'Syncing...' : 'Sync Now'}
                </button>
                <button
                  onClick={handleDisconnect}
                  className="btn btn-ghost btn-sm"
                  style={{ gap: 5, display: 'flex', alignItems: 'center', color: 'var(--accent-red)', borderColor: 'rgba(239,68,68,0.2)' }}
                >
                  <Unlink size={12} /> Disconnect
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
