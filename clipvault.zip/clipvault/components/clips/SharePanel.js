import { useState } from 'react';
import { Copy, Check, ChevronDown, ChevronUp, Download } from 'lucide-react';

function ShareOption({ platform, color, emoji, content, label }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div style={{ borderRadius: 'var(--radius-md)', border: '1px solid var(--border-subtle)', overflow: 'hidden', marginBottom: 8 }}>
      <button
        onClick={() => setOpen(!open)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 10,
          padding: '10px 14px', background: open ? 'var(--bg-elevated)' : 'var(--bg-surface)',
          transition: 'background 0.15s',
        }}
      >
        <span style={{ fontSize: 16 }}>{emoji}</span>
        <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-primary)' }}>{platform}</span>
        <span style={{ fontSize: 12, color: 'var(--text-tertiary)', marginLeft: 4 }}>{label}</span>
        <span style={{ marginLeft: 'auto', color: 'var(--text-tertiary)' }}>
          {open ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </span>
      </button>

      {open && (
        <div style={{ padding: '10px 14px', borderTop: '1px solid var(--border-subtle)', background: 'var(--bg-base)' }}>
          <pre style={{
            fontFamily: 'var(--font-mono)', fontSize: 12,
            color: 'var(--text-secondary)', background: 'var(--bg-surface)',
            border: '1px solid var(--border-subtle)',
            borderRadius: 'var(--radius-sm)', padding: '10px 12px',
            whiteSpace: 'pre-wrap', wordBreak: 'break-all',
            marginBottom: 10, lineHeight: 1.6,
          }}>{content}</pre>
          <button
            onClick={handleCopy}
            className="btn btn-sm"
            style={{
              background: copied ? 'rgba(16,185,129,0.15)' : `${color}22`,
              color: copied ? 'var(--accent-green)' : color,
              border: `1px solid ${copied ? 'rgba(16,185,129,0.3)' : color + '44'}`,
              display: 'flex', alignItems: 'center', gap: 6,
            }}
          >
            {copied ? <Check size={12} /> : <Copy size={12} />}
            {copied ? 'Copied!' : `Copy for ${platform}`}
          </button>
        </div>
      )}
    </div>
  );
}

export default function SharePanel({ clip }) {
  const clipUrl = `https://clipvault.gg/clip/${clip.id}`;

  const shares = [
    {
      platform: 'TikTok', emoji: '🎵', color: '#ff0050', label: 'caption + hashtags',
      content: `${clip.title}\n\nWatch the full clip on ClipVault: ${clipUrl}\n\n#${clip.game.replace(/\s/g, '')} #ClipVault #Gaming #${clip.game.replace(/\s/g, '')}Clips #GamingMoments #FPS #Clutch #GamingHighlights`,
    },
    {
      platform: 'YouTube', emoji: '▶️', color: '#ff0000', label: 'title + description',
      content: `Title: ${clip.title}\n\nDescription:\n${clip.title} — uploaded from ClipVault\n\nGame: ${clip.game}\nPlatform: ${clip.platform.toUpperCase()}\n\nWant to vault your own clips? 👉 ${clipUrl}\n\nTags: ${clip.game}, gaming, clips, highlights, clutch`,
    },
    {
      platform: 'Discord', emoji: '💬', color: '#5865f2', label: 'rich embed text',
      content: `**${clip.title}**\n🎮 **${clip.game}** · uploaded by **${clip.uploader}**\n👁️ ${clip.views?.toLocaleString()} views · 🔥 ${clip.reactions?.fire} fire reactions\n\n${clipUrl}`,
    },
    {
      platform: 'Twitter / X', emoji: '🐦', color: '#1d9bf0', label: 'ready-to-tweet',
      content: `${clip.title.slice(0, 160)}\n\n#${clip.game.replace(/\s/g, '')} #Gaming @ClipVaultGG\n\n${clipUrl}`,
    },
    {
      platform: 'Reddit', emoji: '🔴', color: '#ff4500', label: 'post title',
      content: `[${clip.game}] ${clip.title}\n\nFull clip + context: ${clipUrl}`,
    },
  ];

  const [copiedLink, setCopiedLink] = useState(false);
  const copyLink = () => {
    navigator.clipboard.writeText(clipUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div>
      <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 600, marginBottom: 14, color: 'var(--text-primary)' }}>
        Share & Export
      </h3>

      {/* Direct link */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <input readOnly value={clipUrl} style={{ flex: 1, fontSize: 12, fontFamily: 'var(--font-mono)', color: 'var(--text-tertiary)' }} />
        <button onClick={copyLink} className="btn btn-secondary btn-sm" style={{ flexShrink: 0, gap: 6 }}>
          {copiedLink ? <Check size={12} /> : <Copy size={12} />}
          {copiedLink ? 'Copied!' : 'Copy'}
        </button>
      </div>

      {/* Platform shares */}
      {shares.map(s => <ShareOption key={s.platform} {...s} />)}

      {/* Download */}
      <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
        <button className="btn btn-ghost btn-sm" style={{ flex: 1, gap: 6 }}>
          <Download size={13} /> Download Clip
        </button>
        <button className="btn btn-ghost btn-sm" style={{ flex: 1, gap: 6 }}>
          <Download size={13} /> Download Thumbnail
        </button>
      </div>
    </div>
  );
}
