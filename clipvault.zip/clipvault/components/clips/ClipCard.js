import Link from 'next/link';
import { Eye, Heart, Flame, Laugh, Brain, Crown } from 'lucide-react';
import { formatNumber } from '../../lib/mockData';

export default function ClipCard({ clip, index = 0 }) {
  const totalReactions = Object.values(clip.reactions || {}).reduce((a, b) => a + b, 0);

  return (
    <Link href={`/clip/${clip.id}`} style={{ animationDelay: `${index * 0.05}s` }} className="animate-in">
      <div style={{
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-lg)',
        overflow: 'hidden',
        cursor: 'pointer',
        transition: 'all 0.2s ease',
      }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--border-mid)'; e.currentTarget.style.transform = 'translateY(-3px)'; }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border-subtle)'; e.currentTarget.style.transform = 'translateY(0)'; }}
      >
        {/* Thumbnail */}
        <div style={{ position: 'relative', aspectRatio: '16/9', background: `linear-gradient(135deg, ${clip.color}22, ${clip.color}44)`, overflow: 'hidden' }}>
          <div style={{
            position: 'absolute', inset: 0,
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center', gap: 8,
          }}>
            <div style={{ fontSize: 28, opacity: 0.15, fontFamily: 'var(--font-display)', fontWeight: 700, color: clip.color, textAlign: 'center', padding: '0 12px' }}>
              {clip.game}
            </div>
            <div style={{
              width: 44, height: 44, borderRadius: '50%',
              background: 'rgba(0,0,0,0.4)',
              border: `2px solid ${clip.color}60`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <div style={{ width: 0, height: 0, borderStyle: 'solid', borderWidth: '8px 0 8px 14px', borderColor: `transparent transparent transparent ${clip.color}` }} />
            </div>
          </div>

          {/* Duration */}
          <div style={{
            position: 'absolute', bottom: 8, right: 8,
            background: 'rgba(0,0,0,0.75)',
            color: 'white', fontSize: 11,
            fontFamily: 'var(--font-mono)',
            padding: '2px 7px', borderRadius: 4,
          }}>{clip.duration}</div>

          {/* Live badge */}
          {clip.isLive && (
            <div style={{ position: 'absolute', top: 8, left: 8 }}>
              <span className="live-badge">LIVE</span>
            </div>
          )}

          {/* Platform badge */}
          <div style={{
            position: 'absolute', top: 8, right: 8,
            background: 'rgba(0,0,0,0.6)',
            borderRadius: 4, padding: '2px 6px',
            fontSize: 10, color: 'rgba(255,255,255,0.7)',
            fontFamily: 'var(--font-display)',
            textTransform: 'uppercase', letterSpacing: '0.06em',
          }}>{clip.platform}</div>
        </div>

        {/* Info */}
        <div style={{ padding: '12px 14px' }}>
          <div style={{
            fontSize: 13, fontWeight: 500,
            color: 'var(--text-primary)',
            lineHeight: 1.4,
            display: '-webkit-box',
            WebkitLineClamp: 2,
            WebkitBoxOrient: 'vertical',
            overflow: 'hidden',
            marginBottom: 8,
          }}>{clip.title}</div>

          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>
              <span style={{ color: clip.color, fontWeight: 500 }}>{clip.game}</span>
              {' · '}
              <span>{clip.uploader}</span>
            </div>
          </div>

          {/* Stats row */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8 }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--text-tertiary)' }}>
              <Eye size={12} /> {formatNumber(clip.views)}
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--text-tertiary)' }}>
              <Heart size={12} /> {formatNumber(clip.likes)}
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--text-tertiary)', marginLeft: 'auto' }}>
              🔥{formatNumber(clip.reactions.fire)}
              <span style={{ marginLeft: 4 }}>👑{formatNumber(clip.reactions.clutch)}</span>
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
}
