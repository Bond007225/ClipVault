import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { Home, Compass, Upload, Users, BarChart2, Settings, Zap, Menu, X, Bell, Search } from 'lucide-react';

const NAV = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/discover', label: 'Discover', icon: Compass },
  { href: '/upload', label: 'Upload Clip', icon: Upload },
  { href: '/platforms', label: 'Platforms', icon: Zap },
  { href: '/leaderboard', label: 'Leaderboard', icon: Users },
  { href: '/projections', label: 'Projections', icon: BarChart2 },
  { href: '/settings', label: 'Settings', icon: Settings },
];

export default function Layout({ children }) {
  const router = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg-void)' }}>
      {/* Sidebar */}
      <aside style={{
        width: 220, flexShrink: 0, background: 'var(--bg-base)',
        borderRight: '1px solid var(--border-subtle)',
        display: 'flex', flexDirection: 'column',
        position: 'fixed', top: 0, left: 0, bottom: 0, zIndex: 100,
        transform: sidebarOpen ? 'translateX(0)' : 'translateX(-100%)',
        transition: 'transform 0.25s ease',
      }}
      className="sidebar"
      >
        {/* Logo */}
        <div style={{ padding: '20px 20px 16px', borderBottom: '1px solid var(--border-subtle)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 34, height: 34, borderRadius: 8,
              background: 'linear-gradient(135deg, var(--accent-purple), var(--accent-cyan))',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 16, fontWeight: 700, color: 'white', fontFamily: 'var(--font-display)',
            }}>CV</div>
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, letterSpacing: '0.04em' }}>
              Clip<span style={{ color: 'var(--accent-purple)' }}>Vault</span>
            </span>
          </div>
          <div style={{ marginTop: 6 }}>
            <span className="live-badge">LIVE</span>
            <span style={{ fontSize: 11, color: 'var(--text-tertiary)', marginLeft: 6 }}>15,000 users</span>
          </div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '12px 10px', display: 'flex', flexDirection: 'column', gap: 2 }}>
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = router.pathname === href;
            return (
              <Link key={href} href={href} onClick={() => setSidebarOpen(false)} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '9px 12px', borderRadius: 'var(--radius-md)',
                fontSize: 14, fontWeight: active ? 500 : 400,
                color: active ? 'var(--text-primary)' : 'var(--text-secondary)',
                background: active ? 'var(--bg-elevated)' : 'transparent',
                transition: 'all 0.15s',
                borderLeft: active ? '2px solid var(--accent-purple)' : '2px solid transparent',
              }}>
                <Icon size={16} />
                {label}
                {href === '/upload' && (
                  <span style={{ marginLeft: 'auto', background: 'var(--accent-purple)', borderRadius: 4, padding: '1px 6px', fontSize: 10, color: 'white', fontWeight: 600 }}>+</span>
                )}
              </Link>
            );
          })}
        </nav>

        {/* User profile stub */}
        <div style={{ padding: '12px 14px', borderTop: '1px solid var(--border-subtle)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 32, height: 32, borderRadius: '50%',
              background: 'linear-gradient(135deg, var(--accent-purple), var(--accent-cyan))',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 13, fontWeight: 600, color: 'white',
            }}>U</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 500 }}>Your Vault</div>
              <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>Level 12 • 8 clips</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div style={{ flex: 1, marginLeft: 0, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* Topbar */}
        <header style={{
          height: 58, background: 'var(--bg-base)',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex', alignItems: 'center',
          padding: '0 20px', gap: 12,
          position: 'sticky', top: 0, zIndex: 90,
        }}>
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            style={{ background: 'none', color: 'var(--text-secondary)', padding: 4, display: 'flex', alignItems: 'center' }}
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>

          {/* Search */}
          <div style={{ flex: 1, maxWidth: 420, position: 'relative' }}>
            <Search size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
            <input
              placeholder="Search clips, players, games..."
              style={{ paddingLeft: 34, height: 36, fontSize: 13, borderRadius: 'var(--radius-md)' }}
            />
          </div>

          <div style={{ flex: 1 }} />

          <button style={{ background: 'none', color: 'var(--text-secondary)', padding: 4, display: 'flex', position: 'relative' }}>
            <Bell size={18} />
            <span style={{ position: 'absolute', top: 2, right: 2, width: 7, height: 7, background: 'var(--accent-purple)', borderRadius: '50%', border: '1px solid var(--bg-base)' }} />
          </button>

          <Link href="/upload">
            <button className="btn btn-primary btn-sm">Drop a Clip</button>
          </Link>
        </header>

        <main style={{ flex: 1, overflow: 'auto' }}>
          {children}
        </main>
      </div>

      <style jsx global>{`
        @media (min-width: 768px) {
          .sidebar { transform: translateX(0) !important; }
          main > div, main > section { margin-left: 0; }
          body > div > div { margin-left: 220px !important; }
        }
      `}</style>
    </div>
  );
}
