import Layout from '../components/layout/Layout';
import { Settings } from 'lucide-react';

export default function SettingsPage() {
  return (
    <Layout>
      <div style={{ maxWidth: 680, margin: '0 auto', padding: '28px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 28 }}>
          <Settings size={22} style={{ color: 'var(--text-secondary)' }} />
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700 }}>Settings</h1>
        </div>

        {[
          { section: 'Profile', fields: [
            { label: 'Display Name', placeholder: 'Your gamer tag' },
            { label: 'Bio', placeholder: 'Tell the world about your playstyle...' },
          ]},
          { section: 'Creator Monetization', fields: [
            { label: 'PayPal Email', placeholder: 'your@paypal.com' },
            { label: 'Minimum Tip ($)', placeholder: '1.00' },
            { label: 'Subscription Price ($/mo)', placeholder: '4.99' },
          ]},
          { section: 'Notifications', fields: [] },
        ].map(({ section, fields }) => (
          <div key={section} style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-lg)', padding: '20px', marginBottom: 16 }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 16, marginBottom: 16 }}>{section}</h3>
            {fields.map(f => (
              <div key={f.label} style={{ marginBottom: 14 }}>
                <label style={{ display: 'block', fontSize: 13, color: 'var(--text-secondary)', marginBottom: 6 }}>{f.label}</label>
                <input placeholder={f.placeholder} />
              </div>
            ))}
            {section === 'Notifications' && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {['New followers', 'Tips received', 'Clip reactions', 'Platform sync complete'].map(n => (
                  <label key={n} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                    <input type="checkbox" defaultChecked style={{ width: 'auto' }} />
                    <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{n}</span>
                  </label>
                ))}
              </div>
            )}
          </div>
        ))}

        <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}>Save Changes</button>
      </div>
    </Layout>
  );
}
