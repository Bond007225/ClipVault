import { useRouter } from 'next/router';
import Layout from '../../components/layout/Layout';
import SharePanel from '../../components/clips/SharePanel';
import { MOCK_CLIPS, formatNumber } from '../../lib/mockData';
import { Eye, Heart, ArrowLeft, BarChart2 } from 'lucide-react';
import { useState } from 'react';

const REACTIONS = [
  { key: 'fire', emoji: '🔥', label: 'Fire' },
  { key: 'lol', emoji: '😂', label: 'LOL' },
  { key: 'mindblown', emoji: '🤯', label: 'Mind-blown' },
  { key: 'clutch', emoji: '👑', label: 'Clutch' },
];

export default function ClipDetail() {
  const router = useRouter();
  const { id } = router.query;
  const clip = MOCK_CLIPS.find(c => c.id === id) || MOCK_CLIPS[0];
  const [reactions, setReactions] = useState(clip.reactions);
  const [reacted, setReacted] = useState(null);

  const handleReact = (key) => {
    if (reacted) return;
    setReactions(r => ({ ...r, [key]: r[key] + 1 }));
    setReacted(key);
  };

  return (
    <Layout>
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '28px 24px' }}>
        <button onClick={() => router.back()} className="btn btn-ghost btn-sm" style={{ marginBottom: 20, display: 'flex', alignItems: 'center', gap: 6 }}>
          <ArrowLeft size={14} /> Back
        </button>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 28, alignItems: 'start' }}>
          {/* Main */}
          <div>
            {/* Video player placeholder */}
            <div style={{
              aspectRatio: '16/9',
              background: `linear-gradient(135deg, ${clip.color}18, ${clip.color}30)`,
              borderRadius: 'var(--radius-lg)',
              border: '1px solid var(--border-mid)',
              display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
              gap: 16, marginBottom: 20, position: 'relative', overflow: 'hidden',
            }}>
              <div style={{ fontSize: 48, opacity: 0.12, fontFamily: 'var(--font-display)', fontWeight: 700, color: clip.color, position: 'absolute' }}>{clip.game}</div>
              <div style={{
                width: 64, height: 64, borderRadius: '50%',
                background: 'rgba(0,0,0,0.5)',
                border: `2px solid ${clip.color}80`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                cursor: 'pointer', zIndex: 1,
              }}>
                <div style={{ width: 0, height: 0, borderStyle: 'solid', borderWidth: '12px 0 12px 20px', borderColor: `transparent transparent transparent ${clip.color}`, marginLeft: 4 }} />
              </div>
              <div style={{ fontSize: 14, color: 'var(--text-secondary)', zIndex: 1 }}>Click to play</div>
              {clip.isLive && <div style={{ position: 'absolute', top: 14, left: 14 }}><span className="live-badge">LIVE</span></div>}
            </div>

            {/* Title + meta */}
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, marginBottom: 10, lineHeight: 1.3 }}>{clip.title}</h1>

            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
              <span style={{ fontSize: 13, color: clip.color, fontWeight: 500 }}>{clip.game}</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: 'var(--text-tertiary)' }}><Eye size={13} /> {formatNumber(clip.views)}</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 13, color: 'var(--text-tertiary)' }}><Heart size={13} /> {formatNumber(clip.likes)}</span>
              <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>by <strong style={{ color: 'var(--text-secondary)' }}>{clip.uploader}</strong></span>
            </div>

            {/* Reactions */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 24 }}>
              {REACTIONS.map(r => (
                <button
                  key={r.key}
                  onClick={() => handleReact(r.key)}
                  style={{
                    display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                    padding: '10px 16px',
                    background: reacted === r.key ? `${clip.color}20` : 'var(--bg-surface)',
                    border: `1px solid ${reacted === r.key ? clip.color + '60' : 'var(--border-subtle)'}`,
                    borderRadius: 'var(--radius-md)', cursor: reacted ? 'default' : 'pointer',
                    transition: 'all 0.15s',
                  }}
                >
                  <span style={{ fontSize: 20 }}>{r.emoji}</span>
                  <span style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: 'var(--text-secondary)' }}>{formatNumber(reactions[r.key])}</span>
                  <span style={{ fontSize: 10, color: 'var(--text-tertiary)' }}>{r.label}</span>
                </button>
              ))}
            </div>

            {/* Analytics card */}
            <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-lg)', padding: '18px 20px', marginBottom: 20 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
                <BarChart2 size={15} style={{ color: 'var(--accent-purple)' }} />
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 16 }}>Clip Analytics</h3>
                <span className="badge badge-purple" style={{ marginLeft: 4 }}>OWNER VIEW</span>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
                {[
                  { label: 'Total Views', value: formatNumber(clip.views), color: 'var(--accent-cyan)' },
                  { label: 'Reactions', value: formatNumber(Object.values(reactions).reduce((a,b)=>a+b,0)), color: 'var(--accent-red)' },
                  { label: 'New Followers', value: '+' + Math.floor(clip.views / 800), color: 'var(--accent-green)' },
                  { label: 'Peak Day', value: 'Today', color: 'var(--accent-amber)' },
                ].map(s => (
                  <div key={s.label} style={{ background: 'var(--bg-base)', borderRadius: 'var(--radius-sm)', padding: '10px 12px' }}>
                    <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: s.color }}>{s.value}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 2 }}>{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Share panel sidebar */}
          <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-lg)', padding: '20px' }}>
            <SharePanel clip={clip} />
          </div>
        </div>
      </div>
    </Layout>
  );
}
