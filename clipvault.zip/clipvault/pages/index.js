import Layout from '../components/layout/Layout';
import ClipCard from '../components/clips/ClipCard';
import { MOCK_CLIPS, MOCK_USERS, STATS, formatNumber } from '../lib/mockData';
import { Flame, TrendingUp, Star, Zap } from 'lucide-react';

const GAMES_FILTER = ['All', 'Valorant', 'CS2', 'Fortnite', 'Apex Legends', 'Elden Ring', 'Call of Duty'];

export default function Home() {
  return (
    <Layout>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '28px 24px' }}>

        {/* Hero stats bar */}
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
          gap: 10, marginBottom: 32,
        }}>
          {[
            { label: 'Active Users', value: formatNumber(STATS.totalUsers), icon: '👤', color: 'var(--accent-purple)' },
            { label: 'Clips Vaulted', value: formatNumber(STATS.totalClips), icon: '🎮', color: 'var(--accent-cyan)' },
            { label: 'Total Views', value: formatNumber(STATS.totalViews), icon: '👁️', color: 'var(--accent-amber)' },
            { label: 'Reactions', value: formatNumber(STATS.totalReactions), icon: '🔥', color: 'var(--accent-red)' },
            { label: 'Tips Sent', value: `$${formatNumber(STATS.tipsSent)}`, icon: '💰', color: 'var(--accent-green)' },
          ].map(s => (
            <div key={s.label} style={{
              background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)',
              borderRadius: 'var(--radius-md)', padding: '14px 16px',
            }}>
              <div style={{ fontSize: 18 }}>{s.icon}</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: s.color, lineHeight: 1.2, marginTop: 4 }}>{s.value}</div>
              <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginTop: 2 }}>{s.label}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 28, alignItems: 'start' }}>
          {/* Feed */}
          <div>
            {/* Section header */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
              <Flame size={18} style={{ color: 'var(--accent-red)' }} />
              <h2 style={{ fontSize: 20, fontFamily: 'var(--font-display)' }}>Trending Clips</h2>
              <span className="badge badge-red" style={{ marginLeft: 4 }}>HOT</span>
              <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
                {['All', 'Valorant', 'CS2', 'Fortnite'].map(g => (
                  <button key={g} className="btn btn-ghost btn-sm"
                    style={{ fontSize: 12, padding: '4px 12px' }}>
                    {g}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
              {MOCK_CLIPS.map((clip, i) => (
                <ClipCard key={clip.id} clip={clip} index={i} />
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            {/* Top creators */}
            <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-lg)', padding: '18px 20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16 }}>
                <Star size={15} style={{ color: 'var(--accent-amber)' }} />
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 16 }}>Top Creators</h3>
              </div>

              {MOCK_USERS.slice(0, 5).map((user, i) => (
                <div key={user.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: i < 4 ? '1px solid var(--border-subtle)' : 'none' }}>
                  <span style={{ fontSize: 12, color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)', width: 16 }}>#{i + 1}</span>
                  <div style={{
                    width: 32, height: 32, borderRadius: '50%',
                    background: `linear-gradient(135deg, var(--accent-purple), var(--accent-cyan))`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 12, fontWeight: 600, color: 'white', flexShrink: 0,
                  }}>{user.username[0].toUpperCase()}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {user.username}
                      {user.verified && <span style={{ marginLeft: 4, fontSize: 10 }}>✓</span>}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{formatNumber(user.followers)} followers</div>
                  </div>
                  <span style={{ fontSize: 11, color: 'var(--accent-cyan)', fontFamily: 'var(--font-mono)' }}>{user.clips} clips</span>
                </div>
              ))}
            </div>

            {/* Platform connect CTA */}
            <div style={{
              background: 'linear-gradient(135deg, rgba(124,58,237,0.15), rgba(6,182,212,0.1))',
              border: '1px solid rgba(124,58,237,0.25)',
              borderRadius: 'var(--radius-lg)',
              padding: '18px 20px',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <Zap size={16} style={{ color: 'var(--accent-purple)' }} />
                <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 15 }}>Connect Platforms</h3>
              </div>
              <p style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 12, lineHeight: 1.5 }}>
                Auto-import from Twitch, PSN, Xbox & Steam. Share everywhere in one click.
              </p>
              <a href="/platforms">
                <button className="btn btn-primary btn-sm" style={{ width: '100%', justifyContent: 'center' }}>
                  Connect Now
                </button>
              </a>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
