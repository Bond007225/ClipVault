import Layout from '../components/layout/Layout';
import { MOCK_USERS, formatNumber } from '../lib/mockData';
import { Trophy, Flame } from 'lucide-react';

const PLATFORMS_COLORS = { psn: '#003791', twitch: '#9146ff', xbox: '#107c10', steam: '#4a90d9' };

export default function Leaderboard() {
  const extended = [
    ...MOCK_USERS,
    { id:'u9', username:'StormBreakerTV', level:33, clips:55, followers:7200, views:428000, badges:['🔥','⚡'], verified:false, platform:'twitch', game:'Valorant' },
    { id:'u10', username:'GhostProtocol_', level:27, clips:29, followers:2900, views:167000, badges:['🎯'], verified:false, platform:'psn', game:'Fortnite' },
    { id:'u11', username:'QuantumFrag', level:36, clips:82, followers:9400, views:612000, badges:['👑','🔥','💎'], verified:true, platform:'steam', game:'CS2' },
    { id:'u12', username:'AceOfSpades_GG', level:31, clips:47, followers:5100, views:334000, badges:['🌟','⚡'], verified:false, platform:'xbox', game:'Apex Legends' },
    { id:'u13', username:'ThunderClap99', level:40, clips:108, followers:13200, views:823000, badges:['🏆','🔥','🚀'], verified:true, platform:'twitch', game:'Fortnite' },
    { id:'u14', username:'SilentAssassin', level:25, clips:22, followers:1800, views:98000, badges:['🎯'], verified:false, platform:'psn', game:'Valorant' },
    { id:'u15', username:'MidnightGrinder', level:43, clips:139, followers:16700, views:1100000, badges:['🏆','👑','⚡','💎'], verified:true, platform:'steam', game:'CS2' },
    { id:'u16', username:'EchoStrike', level:29, clips:38, followers:3700, views:221000, badges:['🔥','🎯'], verified:false, platform:'xbox', game:'Call of Duty' },
    { id:'u17', username:'IronCurtainGG', level:38, clips:91, followers:10800, views:698000, badges:['👑','🔥','🌟'], verified:true, platform:'twitch', game:'Elden Ring' },
    { id:'u18', username:'LaserFocused', level:22, clips:15, followers:1100, views:62000, badges:['⚡'], verified:false, platform:'psn', game:'Apex Legends' },
    { id:'u19', username:'ZeroGravityGG', level:46, clips:167, followers:21400, views:1590000, badges:['🏆','👑','💎','🚀','⚡'], verified:true, platform:'steam', game:'Valorant' },
    { id:'u20', username:'ProxyWarfare', level:34, clips:71, followers:8100, views:489000, badges:['🔥','🎯','🌟'], verified:true, platform:'twitch', game:'CS2' },
  ].sort((a,b) => b.views - a.views);

  return (
    <Layout>
      <div style={{ maxWidth: 900, margin: '0 auto', padding: '28px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 28 }}>
          <Trophy size={22} style={{ color: 'var(--accent-amber)' }} />
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700 }}>Leaderboard</h1>
          <span className="badge badge-amber">TOP 20</span>
        </div>

        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
          {/* Table header */}
          <div style={{ display: 'grid', gridTemplateColumns: '40px 1fr 80px 90px 90px 80px 120px', gap: 0, padding: '10px 20px', borderBottom: '1px solid var(--border-subtle)', background: 'var(--bg-base)' }}>
            {['#', 'Player', 'Level', 'Clips', 'Views', 'Followers', 'Badges'].map(h => (
              <span key={h} style={{ fontSize: 11, color: 'var(--text-tertiary)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</span>
            ))}
          </div>

          {extended.map((user, i) => {
            const rankColor = i === 0 ? '#FFD700' : i === 1 ? '#C0C0C0' : i === 2 ? '#CD7F32' : 'var(--text-tertiary)';
            return (
              <div key={user.id} style={{
                display: 'grid', gridTemplateColumns: '40px 1fr 80px 90px 90px 80px 120px',
                alignItems: 'center', padding: '12px 20px',
                borderBottom: i < extended.length - 1 ? '1px solid var(--border-subtle)' : 'none',
                transition: 'background 0.15s',
                background: i < 3 ? `rgba(255,215,0,0.02)` : 'transparent',
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-elevated)'}
              onMouseLeave={e => e.currentTarget.style.background = i < 3 ? 'rgba(255,215,0,0.02)' : 'transparent'}
              >
                <span style={{ fontSize: 14, fontFamily: 'var(--font-mono)', fontWeight: 700, color: rankColor }}>
                  {i < 3 ? ['🥇','🥈','🥉'][i] : `#${i + 1}`}
                </span>

                <div style={{ display: 'flex', alignItems: 'center', gap: 10, minWidth: 0 }}>
                  <div style={{
                    width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
                    background: `linear-gradient(135deg, var(--accent-purple), var(--accent-cyan))`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 13, fontWeight: 600, color: 'white',
                    border: `2px solid ${PLATFORMS_COLORS[user.platform] || 'transparent'}`,
                  }}>{user.username[0].toUpperCase()}</div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', gap: 5 }}>
                      {user.username}
                      {user.verified && <span style={{ fontSize: 10, color: 'var(--accent-cyan)' }}>✓</span>}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>{user.game}</div>
                  </div>
                </div>

                <span style={{ fontSize: 13, color: 'var(--accent-purple)', fontFamily: 'var(--font-mono)', fontWeight: 500 }}>Lv.{user.level}</span>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' }}>{user.clips}</span>
                <span style={{ fontSize: 13, color: 'var(--accent-cyan)', fontFamily: 'var(--font-mono)' }}>{formatNumber(user.views)}</span>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' }}>{formatNumber(user.followers)}</span>
                <span style={{ fontSize: 16, letterSpacing: 2 }}>{user.badges.join('')}</span>
              </div>
            );
          })}
        </div>
      </div>
    </Layout>
  );
}
