import { useState } from 'react';
import Layout from '../components/layout/Layout';
import { GAMES } from '../lib/mockData';
import { Upload, Sparkles, Check } from 'lucide-react';

export default function UploadPage() {
  const [title, setTitle] = useState('');
  const [game, setGame] = useState('');
  const [tags, setTags] = useState([]);
  const [platform, setPlatform] = useState('');
  const [description, setDescription] = useState('');
  const [visibility, setVisibility] = useState('public');
  const [aiLoading, setAiLoading] = useState(false);
  const [gameSearch, setGameSearch] = useState('');
  const [showGameDropdown, setShowGameDropdown] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const filteredGames = GAMES.filter(g => g.name.toLowerCase().includes(gameSearch.toLowerCase()));

  const handleAISuggest = () => {
    if (!game) { alert('Select a game first'); return; }
    setAiLoading(true);
    setTimeout(() => {
      const g = GAMES.find(gm => gm.name === game);
      const titles = {
        'Valorant': '1v5 Clutch with 3hp — the most insane round of my life 🤯',
        'CS2': 'Global Elite reaction time — triple tap headshots',
        'Fortnite': 'Won a 45-kill game with just a grey pump 👑',
        'Apex Legends': 'Wraith portal play that wiped the final squad',
        'Elden Ring': 'Margit first try — no summons, no cheese',
        'default': `Insane ${game} moment — you won't believe this play 🔥`,
      };
      setTitle(titles[game] || titles.default);
      setTags(g?.tags?.slice(0, 5) || ['gaming', 'highlights', 'clutch']);
      setAiLoading(false);
    }, 1400);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title || !game) return;
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <Layout>
      <div style={{ maxWidth: 680, margin: '0 auto', padding: '28px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 28 }}>
          <Upload size={22} style={{ color: 'var(--accent-purple)' }} />
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700 }}>Drop a Clip</h1>
        </div>

        {submitted && (
          <div style={{ background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.3)', borderRadius: 'var(--radius-md)', padding: '12px 16px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
            <Check size={16} style={{ color: 'var(--accent-green)' }} />
            <span style={{ color: 'var(--accent-green)', fontSize: 14, fontWeight: 500 }}>Clip uploaded to your Vault!</span>
          </div>
        )}

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
          {/* Video upload zone */}
          <div style={{
            border: '2px dashed var(--border-mid)', borderRadius: 'var(--radius-lg)',
            padding: '40px 20px', textAlign: 'center',
            background: 'var(--bg-surface)', cursor: 'pointer',
            transition: 'border-color 0.2s',
          }}
          onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent-purple)'}
          onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border-mid)'}
          >
            <div style={{ fontSize: 36, marginBottom: 10 }}>🎬</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Drag & drop your clip here</div>
            <div style={{ fontSize: 13, color: 'var(--text-tertiary)', marginBottom: 14 }}>MP4, MOV, AVI up to 500MB</div>
            <button type="button" className="btn btn-secondary btn-sm">Browse Files</button>
          </div>

          {/* Game select with autocomplete */}
          <div>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 6, color: 'var(--text-secondary)' }}>Game *</label>
            <div style={{ position: 'relative' }}>
              <input
                value={game || gameSearch}
                onChange={e => { setGameSearch(e.target.value); setGame(''); setShowGameDropdown(true); }}
                onFocus={() => setShowGameDropdown(true)}
                placeholder="Search games..."
                required
              />
              {showGameDropdown && gameSearch && (
                <div style={{
                  position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 50,
                  background: 'var(--bg-elevated)', border: '1px solid var(--border-mid)',
                  borderRadius: 'var(--radius-md)', overflow: 'hidden', marginTop: 4,
                  boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
                }}>
                  {filteredGames.slice(0, 6).map(g => (
                    <button
                      key={g.name} type="button"
                      onClick={() => { setGame(g.name); setGameSearch(g.name); setTags(g.tags); setShowGameDropdown(false); }}
                      style={{
                        width: '100%', padding: '10px 14px', textAlign: 'left',
                        background: 'none', display: 'flex', alignItems: 'center', gap: 10,
                        borderBottom: '1px solid var(--border-subtle)',
                        transition: 'background 0.1s',
                      }}
                      onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-hover)'}
                      onMouseLeave={e => e.currentTarget.style.background = 'none'}
                    >
                      <div style={{ width: 8, height: 8, borderRadius: '50%', background: g.color, flexShrink: 0 }} />
                      <span style={{ fontSize: 14, color: 'var(--text-primary)' }}>{g.name}</span>
                      <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
                        {g.tags?.slice(0, 2).map(t => (
                          <span key={t} style={{ fontSize: 10, background: g.color + '18', color: g.color, padding: '1px 6px', borderRadius: 3 }}>{t}</span>
                        ))}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Title with AI suggest */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
              <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-secondary)' }}>Title *</label>
              <button type="button" onClick={handleAISuggest} className="btn btn-ghost btn-sm" style={{ gap: 5, display: 'flex', alignItems: 'center', fontSize: 12 }} disabled={aiLoading}>
                <Sparkles size={12} style={{ color: 'var(--accent-purple)' }} />
                {aiLoading ? 'Generating...' : 'AI Suggest'}
              </button>
            </div>
            <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Give your clip a killer title..." required />
          </div>

          {/* Tags */}
          <div>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 8, color: 'var(--text-secondary)' }}>Tags</label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {tags.map(t => (
                <span key={t} style={{ padding: '4px 10px', background: 'var(--bg-elevated)', border: '1px solid var(--border-mid)', borderRadius: 99, fontSize: 12, color: 'var(--text-secondary)' }}>
                  #{t}
                </span>
              ))}
              {tags.length === 0 && <span style={{ fontSize: 12, color: 'var(--text-tertiary)' }}>Select a game to auto-fill tags</span>}
            </div>
          </div>

          {/* Platform */}
          <div>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 6, color: 'var(--text-secondary)' }}>Platform</label>
            <select value={platform} onChange={e => setPlatform(e.target.value)} style={{ background: 'var(--bg-elevated)' }}>
              <option value="">Select platform</option>
              <option value="psn">PlayStation</option>
              <option value="xbox">Xbox</option>
              <option value="steam">Steam / PC</option>
              <option value="twitch">Twitch</option>
              <option value="other">Other</option>
            </select>
          </div>

          {/* Description */}
          <div>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 6, color: 'var(--text-secondary)' }}>Description</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} placeholder="What happened? Give it context..." style={{ resize: 'vertical' }} />
          </div>

          {/* Visibility */}
          <div>
            <label style={{ display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 8, color: 'var(--text-secondary)' }}>Visibility</label>
            <div style={{ display: 'flex', gap: 10 }}>
              {['public', 'private'].map(v => (
                <button
                  key={v} type="button"
                  onClick={() => setVisibility(v)}
                  className="btn btn-sm"
                  style={{
                    background: visibility === v ? 'var(--accent-purple)' : 'var(--bg-surface)',
                    color: visibility === v ? 'white' : 'var(--text-secondary)',
                    border: `1px solid ${visibility === v ? 'var(--accent-purple)' : 'var(--border-mid)'}`,
                    textTransform: 'capitalize',
                  }}
                >{v === 'public' ? '🌍 ' : '🔒 '}{v}</button>
              ))}
            </div>
          </div>

          <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%', justifyContent: 'center', marginTop: 8 }}>
            🚀 Upload to Vault
          </button>
        </form>
      </div>
    </Layout>
  );
}
