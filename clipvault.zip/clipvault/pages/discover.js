import { useState } from 'react';
import Layout from '../components/layout/Layout';
import ClipCard from '../components/clips/ClipCard';
import { MOCK_CLIPS, GAMES } from '../lib/mockData';
import { Compass } from 'lucide-react';

export default function Discover() {
  const [activeGame, setActiveGame] = useState('All');
  const filters = ['All', ...GAMES.map(g => g.name).slice(0, 8)];

  const filtered = activeGame === 'All'
    ? MOCK_CLIPS
    : MOCK_CLIPS.filter(c => c.game === activeGame);

  return (
    <Layout>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '28px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 20 }}>
          <Compass size={22} style={{ color: 'var(--accent-cyan)' }} />
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700 }}>Discover</h1>
          <span className="badge badge-cyan">PUBLIC</span>
        </div>

        {/* Game filter pills */}
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 24 }}>
          {filters.map(g => {
            const game = GAMES.find(gm => gm.name === g);
            const active = activeGame === g;
            return (
              <button
                key={g}
                onClick={() => setActiveGame(g)}
                style={{
                  padding: '6px 16px', borderRadius: 99,
                  fontSize: 13, fontWeight: 500,
                  background: active ? (game?.color || 'var(--accent-purple)') + '22' : 'var(--bg-surface)',
                  color: active ? (game?.color || 'var(--accent-purple)') : 'var(--text-secondary)',
                  border: `1px solid ${active ? (game?.color || 'var(--accent-purple)') + '50' : 'var(--border-subtle)'}`,
                  transition: 'all 0.15s',
                  cursor: 'pointer',
                }}
              >{g}</button>
            );
          })}
        </div>

        {filtered.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 20px' }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>🎮</div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, marginBottom: 8 }}>No clips here yet</div>
            <div style={{ color: 'var(--text-secondary)', fontSize: 14 }}>Be the first to drop a banger in {activeGame}!</div>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
            {filtered.map((clip, i) => <ClipCard key={clip.id} clip={clip} index={i} />)}
          </div>
        )}
      </div>
    </Layout>
  );
}
