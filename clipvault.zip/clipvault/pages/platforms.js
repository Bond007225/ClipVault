import Layout from '../components/layout/Layout';
import PlatformCard from '../components/platforms/PlatformCard';
import { PLATFORMS, TWITCH_MOCK_CLIPS } from '../lib/mockData';
import { Zap, Download, CheckCircle } from 'lucide-react';
import { useState } from 'react';

export default function Platforms() {
  const [importing, setImporting] = useState({});
  const [imported, setImported] = useState({});

  const handleImport = (clipId) => {
    setImporting(p => ({ ...p, [clipId]: true }));
    setTimeout(() => {
      setImporting(p => ({ ...p, [clipId]: false }));
      setImported(p => ({ ...p, [clipId]: true }));
    }, 1200);
  };

  return (
    <Layout>
      <div style={{ maxWidth: 900, margin: '0 auto', padding: '28px 24px' }}>

        {/* Header */}
        <div style={{ marginBottom: 32 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
            <Zap size={22} style={{ color: 'var(--accent-purple)' }} />
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700 }}>Connected Platforms</h1>
          </div>
          <p style={{ color: 'var(--text-secondary)', fontSize: 14 }}>
            Link your gaming accounts to auto-import clips and share everywhere in one click.
          </p>
        </div>

        {/* Platform grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(380px, 1fr))', gap: 14, marginBottom: 40 }}>
          {PLATFORMS.map(p => <PlatformCard key={p.id} platform={p} />)}
        </div>

        {/* Twitch import section */}
        <div style={{ background: 'var(--bg-surface)', border: '1px solid rgba(145,70,255,0.3)', borderRadius: 'var(--radius-lg)', overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border-subtle)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ fontSize: 18 }}>📡</span>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 18 }}>Twitch Clip Importer</h2>
            <span className="badge badge-purple">DEMO</span>
            <button className="btn btn-primary btn-sm" style={{ marginLeft: 'auto' }}>
              Import All ({TWITCH_MOCK_CLIPS.length})
            </button>
          </div>

          <div style={{ padding: '16px 20px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 12 }}>
              {TWITCH_MOCK_CLIPS.map(clip => (
                <div key={clip.id} style={{
                  background: 'var(--bg-base)', border: '1px solid var(--border-subtle)',
                  borderRadius: 'var(--radius-md)', overflow: 'hidden',
                }}>
                  <div style={{ height: 80, background: `linear-gradient(135deg, ${clip.thumbnail}22, ${clip.thumbnail}44)`, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', fontFamily: 'var(--font-mono)' }}>{clip.duration}</span>
                    <div style={{ position: 'absolute', top: 6, right: 6, background: 'rgba(0,0,0,0.6)', borderRadius: 3, padding: '2px 5px', fontSize: 10, color: 'rgba(255,255,255,0.6)' }}>{clip.views.toLocaleString()} views</div>
                  </div>
                  <div style={{ padding: '10px 12px' }}>
                    <div style={{ fontSize: 12, fontWeight: 500, marginBottom: 4, lineHeight: 1.4 }}>{clip.title}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 10 }}>{clip.game}</div>
                    <button
                      onClick={() => handleImport(clip.id)}
                      className="btn btn-sm"
                      style={{
                        width: '100%', justifyContent: 'center',
                        background: imported[clip.id] ? 'rgba(16,185,129,0.15)' : 'rgba(145,70,255,0.15)',
                        color: imported[clip.id] ? 'var(--accent-green)' : 'var(--accent-purple)',
                        border: `1px solid ${imported[clip.id] ? 'rgba(16,185,129,0.3)' : 'rgba(145,70,255,0.3)'}`,
                        display: 'flex', alignItems: 'center', gap: 6,
                      }}
                      disabled={importing[clip.id] || imported[clip.id]}
                    >
                      {importing[clip.id] ? (
                        <span style={{ fontSize: 11 }}>Importing...</span>
                      ) : imported[clip.id] ? (
                        <><CheckCircle size={11} /> In Vault</>
                      ) : (
                        <><Download size={11} /> Import to Vault</>
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
