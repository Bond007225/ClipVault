import Layout from '../components/layout/Layout';
import { BarChart2, TrendingUp } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

const months = ['M1','M2','M3','M4','M5','M6','M7','M8','M9','M10','M11','M12','M13','M14','M15','M16','M17','M18','M19','M20','M21','M22','M23','M24'];

const conservativeUsers = [850,1800,3200,5100,7800,11200,15500,21000,28000,36000,46000,58000,72000,88000,106000,126000,148000,172000,198000,226000,256000,289000,324000,361000];
const optimisticUsers = [2100,5400,11000,19500,31000,46000,64000,85000,112000,143000,178000,220000,268000,320000,378000,441000,509000,582000,660000,743000,831000,925000,1024000,1128000];

const conservativeMRR = [148,315,560,980,1540,2310,3300,4620,6160,8120,10500,13200,16500,20200,24500,29500,35200,39200,46000,54000,63000,72000,79000,84700];
const optimisticMRR = [368,945,1925,3900,6820,10700,15400,21000,28000,36400,45800,57200,71200,88000,107000,129000,153000,147000,176000,204000,236000,270000,307000,294000];

function fmt(n) {
  if (n >= 1000000) return (n/1000000).toFixed(1)+'M';
  if (n >= 1000) return Math.round(n/1000)+'K';
  return String(n);
}

function MiniChart({ data, color, height = 80 }) {
  const max = Math.max(...data);
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * 100;
    const y = height - (v / max) * (height - 10) - 5;
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg viewBox={`0 0 100 ${height}`} style={{ width: '100%', height }} preserveAspectRatio="none">
      <defs>
        <linearGradient id={`grad-${color.replace('#','')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polygon points={`0,${height} ${points} 100,${height}`} fill={`url(#grad-${color.replace('#','')})`} />
      <polyline points={points} fill="none" stroke={color} strokeWidth="1.5" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

export default function Projections() {
  const [scenario, setScenario] = useState('conservative');
  const users = scenario === 'conservative' ? conservativeUsers : optimisticUsers;
  const mrr = scenario === 'conservative' ? conservativeMRR : optimisticMRR;

  const milestones = {
    conservative: { y1users: '58K', y1arr: '$158K', breakeven: 'Month 14', y2arr: '$1.02M', valuation: '$30M–$50M' },
    optimistic: { y1users: '220K', y1arr: '$686K', breakeven: 'Month 8', y2arr: '$3.53M', valuation: '$80M–$120M' },
  };
  const m = milestones[scenario];

  return (
    <Layout>
      <div style={{ maxWidth: 1000, margin: '0 auto', padding: '28px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
          <BarChart2 size={22} style={{ color: 'var(--accent-purple)' }} />
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700 }}>Growth Projections</h1>
        </div>
        <p style={{ color: 'var(--text-tertiary)', fontSize: 13, marginBottom: 24 }}>Launch date: March 13, 2026 — based on Medal.tv, Outplayed & gaming SaaS benchmarks</p>

        {/* Scenario toggle */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 28 }}>
          {['conservative', 'optimistic'].map(s => (
            <button key={s} onClick={() => setScenario(s)} className="btn btn-sm"
              style={{ textTransform: 'capitalize', background: scenario === s ? 'var(--accent-purple)' : 'var(--bg-surface)', color: scenario === s ? 'white' : 'var(--text-secondary)', border: `1px solid ${scenario === s ? 'var(--accent-purple)' : 'var(--border-mid)'}` }}>
              {s === 'conservative' ? '📉 ' : '📈 '}{s}
            </button>
          ))}
        </div>

        {/* Milestone cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 12, marginBottom: 32 }}>
          {[
            { label: 'Year 1 Users', value: m.y1users, color: 'var(--accent-cyan)' },
            { label: 'Year 1 ARR', value: m.y1arr, color: 'var(--accent-green)' },
            { label: 'Break-even', value: m.breakeven, color: 'var(--accent-amber)' },
            { label: 'Year 2 ARR', value: m.y2arr, color: 'var(--accent-purple)' },
            { label: 'Est. Valuation', value: m.valuation, color: 'var(--accent-red)' },
          ].map(card => (
            <div key={card.label} style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-md)', padding: '14px 16px' }}>
              <div style={{ fontSize: 11, color: 'var(--text-tertiary)', marginBottom: 4 }}>{card.label}</div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: card.color }}>{card.value}</div>
            </div>
          ))}
        </div>

        {/* Charts side by side */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 32 }}>
          {[
            { title: 'User Growth (M1–M24)', data: users, color: '#378ADD', key: 'users' },
            { title: 'Monthly Revenue (M1–M24)', data: mrr, color: '#8b5cf6', key: 'mrr' },
          ].map(chart => (
            <div key={chart.key} style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-lg)', padding: '18px 20px' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 15, fontWeight: 600, marginBottom: 4 }}>{chart.title}</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 700, color: chart.color, marginBottom: 14 }}>
                {fmt(chart.data[chart.data.length - 1])}{chart.key === 'mrr' ? '/mo' : ''}
              </div>
              <MiniChart data={chart.data} color={chart.color} height={100} />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
                <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>Month 1: {fmt(chart.data[0])}</span>
                <span style={{ fontSize: 11, color: 'var(--text-tertiary)' }}>Month 24: {fmt(chart.data[23])}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Comparables table */}
        <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', marginBottom: 32 }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border-subtle)' }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 16 }}>Comparable Platforms</h3>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--bg-base)' }}>
                {['Platform','Founded','Y2 DAU','Y2 Revenue','Valuation','Status'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 11, color: 'var(--text-tertiary)', fontWeight: 500, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                ['Medal.tv','2017','~180K','~$2.1M','$333M','Active'],
                ['Outplayed','2019','~95K','~$800K','~$20M','Acquired'],
                ['Insights.gg','2020','~60K','~$500K','~$15M','Active'],
              ].map(([name,...rest]) => (
                <tr key={name} style={{ borderBottom: '1px solid var(--border-subtle)' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-elevated)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <td style={{ padding: '12px 16px', fontSize: 13, fontWeight: 500 }}>{name}</td>
                  {rest.map((v,i) => <td key={i} style={{ padding: '12px 16px', fontSize: 13, color: 'var(--text-secondary)', fontFamily: i === 0 || i === 2 ? 'var(--font-mono)' : 'inherit' }}>{v}</td>)}
                </tr>
              ))}
              {/* ClipVault highlight row */}
              <tr style={{ background: 'rgba(124,58,237,0.08)', borderBottom: 'none' }}>
                <td style={{ padding: '12px 16px', fontSize: 13, fontWeight: 700, color: '#a78bfa' }}>ClipVault 🔮</td>
                <td style={{ padding: '12px 16px', fontSize: 13, color: '#a78bfa', fontFamily: 'var(--font-mono)' }}>2026</td>
                <td style={{ padding: '12px 16px', fontSize: 13, color: '#a78bfa', fontFamily: 'var(--font-mono)' }}>{scenario === 'optimistic' ? '1.13M' : '361K'} est.</td>
                <td style={{ padding: '12px 16px', fontSize: 13, color: '#a78bfa' }}>{m.y2arr}</td>
                <td style={{ padding: '12px 16px', fontSize: 13, color: '#a78bfa' }}>{m.valuation}</td>
                <td style={{ padding: '12px 16px' }}><span className="badge badge-purple">Projected</span></td>
              </tr>
            </tbody>
          </table>
        </div>

        <p style={{ fontSize: 11, color: 'var(--text-tertiary)', borderTop: '1px solid var(--border-subtle)', paddingTop: 14 }}>
          Projections are illustrative estimates based on comparable platform benchmarks. Not financial advice. Sources: Medal.tv public data, GitNux 2025 gaming app benchmarks, Sensor Tower CPI data.
        </p>
      </div>
    </Layout>
  );
}
