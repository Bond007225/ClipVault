export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { game, platform, description } = req.body;

  if (!process.env.ANTHROPIC_API_KEY) {
    // Fallback mock if no API key set
    return res.json({
      title: `Insane ${game} play — you won't believe this 🔥`,
      tags: ['gaming', 'highlights', 'clutch', game.toLowerCase().replace(/\s/g, ''), 'fps'],
    });
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 300,
        messages: [{
          role: 'user',
          content: `You are a gaming content creator assistant. Generate a catchy, engaging gaming clip title and 5 relevant tags.

Game: ${game}
Platform: ${platform || 'PC'}
Description: ${description || 'A highlight clip'}

Rules:
- Title should be exciting, use emojis, reference the game
- Max 80 characters
- Tags should be lowercase, no spaces, relevant to the game and clip type

Respond ONLY with valid JSON (no markdown): {"title": "...", "tags": ["...", "...", "...", "...", "..."]}`
        }]
      })
    });

    const data = await response.json();
    const text = data.content[0].text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(text);
    res.json(parsed);
  } catch (err) {
    console.error('AI suggest error:', err);
    res.json({
      title: `Epic ${game} moment — clutch play 🎮`,
      tags: ['gaming', 'clips', 'highlights', 'clutch', game.toLowerCase().replace(/\s/g,'')],
    });
  }
}
