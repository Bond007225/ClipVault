# ClipVault 🎮

**The gaming clip vault with seamless platform integration and creator monetization.**

A Next.js web app for gamers to vault, share, and monetize their best gaming moments. Built to compete with Medal.tv and Outplayed with stronger social sharing, platform integrations, and creator tools.

---

## Tech Stack

- **Framework**: Next.js 14 (Pages Router)
- **Styling**: Pure CSS with CSS variables (no Tailwind)
- **Icons**: Lucide React
- **Fonts**: Rajdhani (display) + DM Sans (body) + JetBrains Mono

---

## Getting Started

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Open in browser
http://localhost:3000
```

---

## Pages

| Route | Description |
|-------|-------------|
| `/` | Home feed — trending clips + creator leaderboard |
| `/discover` | Public clip discovery with game filters |
| `/upload` | Upload page with AI title suggestion + game autocomplete |
| `/clip/[id]` | Clip detail with reactions, analytics, share panel |
| `/platforms` | Platform connection hub + Twitch importer |
| `/leaderboard` | Top 20 creators ranked by views |
| `/projections` | Investor-grade growth projections (conservative/optimistic) |
| `/settings` | Profile + monetization settings |

---

## Features

### 🎮 Platform Integrations
- Twitch, YouTube, TikTok, Discord, Twitter/X, PSN, Xbox, Steam
- One-click connect with username/OAuth flow
- Auto-import Twitch clips with metadata pre-filled
- Sync button per platform

### 📤 One-Click Sharing
On every clip detail page:
- **TikTok**: Pre-filled caption + hashtags
- **YouTube**: Title, description, tags ready to paste
- **Discord**: Rich embed formatted text
- **Twitter/X**: Pre-filled tweet with char count
- **Reddit**: Post title for r/gaming
- Copy link, copy embed code, download clip

### 🤖 AI-Powered Upload
- Game autocomplete with cover art suggestions
- AI title generator (calls Anthropic API in production)
- Auto-suggested tags per game

### 🔥 Reactions
4-emoji reaction system: 🔥 Fire · 😂 LOL · 🤯 Mind-blown · 👑 Clutch

### 📊 Analytics
Per-clip stats: views, reactions, new followers, peak day

### 💰 Creator Monetization
- Tips system (10% platform fee)
- Subscriptions ($4.99/mo)
- PayPal payout integration

---

## Adding AI Title Generation (Production)

In `pages/upload.js`, replace the `handleAISuggest` timeout mock with:

```js
const handleAISuggest = async () => {
  setAiLoading(true);
  const res = await fetch('/api/ai-suggest', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ game, platform, description }),
  });
  const { title, tags } = await res.json();
  setTitle(title);
  setTags(tags);
  setAiLoading(false);
};
```

Then create `pages/api/ai-suggest.js`:

```js
export default async function handler(req, res) {
  const { game, platform, description } = req.body;
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 300,
      messages: [{
        role: 'user',
        content: `Generate a catchy gaming clip title and 5 relevant tags for: Game: ${game}, Platform: ${platform}, Description: ${description}. Reply with JSON: {"title": "...", "tags": ["...", ...]}`
      }]
    })
  });
  const data = await response.json();
  const parsed = JSON.parse(data.content[0].text);
  res.json(parsed);
}
```

Set `ANTHROPIC_API_KEY` in `.env.local`.

---

## Deployment

### Vercel (recommended)
```bash
npm install -g vercel
vercel
```

### Netlify
```bash
npm run build
# deploy the .next folder
```

---

## Project Structure

```
clipvault/
├── pages/
│   ├── index.js          # Home feed
│   ├── discover.js       # Discover page
│   ├── upload.js         # Upload with AI
│   ├── platforms.js      # Platform hub
│   ├── leaderboard.js    # Top creators
│   ├── projections.js    # Investor projections
│   ├── settings.js       # Settings
│   └── clip/[id].js      # Clip detail
├── components/
│   ├── layout/Layout.js  # Sidebar + topbar
│   ├── clips/
│   │   ├── ClipCard.js   # Clip thumbnail card
│   │   └── SharePanel.js # Share & export panel
│   └── platforms/
│       └── PlatformCard.js
├── lib/
│   └── mockData.js       # Mock users, clips, platforms
├── styles/
│   └── globals.css       # Design system + CSS variables
└── next.config.js
```

---

## Competitive Advantages vs Medal.tv

| Feature | Medal.tv | ClipVault |
|---------|----------|-----------|
| Social export | Basic | One-click TikTok/YT/Discord/Twitter |
| Creator tips | ❌ | ✅ Built-in |
| Subscriptions | ❌ | ✅ $4.99/mo |
| Emoji reactions | ❌ | ✅ 4 types |
| AI title gen | ❌ | ✅ |
| Platform sync | Limited | Twitch + PSN + Xbox + Steam |
| Discover feed | ✅ | ✅ + game filters |

---

## License

MIT — build whatever you want with it.
